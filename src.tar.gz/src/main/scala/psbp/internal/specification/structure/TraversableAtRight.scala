// package psbp.internal.specification.structure

// import psbp.external.specification.program.Program

// import psbp.external.specification.structure.Traversable

// private[psbp] trait TraversableAtRight[A[+ _, + _], >-->[- _, + _]: Program]:
//   private[psbp] def rightTraversable[Y]: Traversable[[X] =>> A[Y, X], >-->] 
