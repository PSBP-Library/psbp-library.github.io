package psbp.external.specification.program

trait FunctionalClassification[>-->[- _, + _]]
  extends Functional[>-->]
  with Classification[>-->]