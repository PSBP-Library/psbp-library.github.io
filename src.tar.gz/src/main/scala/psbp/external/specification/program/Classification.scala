package psbp.external.specification.program

trait Classification[>-->[- _, + _]]
  extends Identity[>-->]
  with Composition[>-->]