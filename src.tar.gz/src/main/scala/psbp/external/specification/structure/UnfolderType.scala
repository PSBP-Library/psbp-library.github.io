package psbp.external.specification.structure

private[psbp] trait UnfolderType:

  // declared

  private[psbp] type Unfolder[X, Y]


  

  