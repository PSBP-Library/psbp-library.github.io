package psbp.external.specification.structure

private[psbp] trait FolderType:

  // declared

  private[psbp] type Folder[Y, X]

