// package psbp.implementation.active

// import psbp.internal.specification.lifting.FunctionApplicationLifting

// import psbp.internal.specification.computation.computationFromResultingAndBinding

// import psbp.internal.specification.computation.functionApplicationLiftingFromComputation

// given activeFunctionApplicationLifting: FunctionApplicationLifting[Active] = functionApplicationLiftingFromComputation[Active]
