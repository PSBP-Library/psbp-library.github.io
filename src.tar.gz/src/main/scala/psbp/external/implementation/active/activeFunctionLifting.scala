// package psbp.implementation.active

// import psbp.internal.specification.lifting.FunctionLifting

// import psbp.internal.specification.lifting.functionLiftingFromFunctionApplicationLifting

// given activeFunctionLifting: FunctionLifting[Active] = functionLiftingFromFunctionApplicationLifting[Active]