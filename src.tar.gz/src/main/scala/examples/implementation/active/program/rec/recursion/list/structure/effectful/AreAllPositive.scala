package examples.implementation.active.program.rec.recursion.list.structure.effectful

import psbp.implementation.active.given

import psbp.external.implementation.rec.given 

import psbp.external.implementation.list.given 

import examples.specification.program.recursive.structure.implementation.list.effectful.mainAreAllPositive

@main def areAllPositive(args: String*): Unit =
  mainAreAllPositive materialized ()

