package psbp.internal.specification.lifting

private[psbp] trait Function1LiftingAtLeft[A[+ _, + _]]:

  private[psbp] def leftFunction1Lifting[X]: 
    Function1Lifting[[Y] =>> A[Y, X]]