package psbp.internal.specification.lifting

private[psbp] trait Function1Lifting[C[+ _]]:

  // declared

  private[psbp] def lift1[Z, Y]: (Z => Y) => C[Z] => C[Y]
