package psbp.specification.aggregatable.rec

private[psbp] trait RecStructureType:

  private[psbp] type Structure[Y, X]



