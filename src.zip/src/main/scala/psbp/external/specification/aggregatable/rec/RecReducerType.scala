package psbp.specification.aggregatable.rec

import psbp.specification.aggregatable.ReducerType

trait RecReducerType[A[+ _, + _]] extends ReducerType:

  override type Reducer[Y, X] = A[Y, X] => X

