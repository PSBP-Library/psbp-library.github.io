package psbp.specification.aggregatable

private[psbp] trait ReducerType:

  // declared

  private[psbp] type Reducer[Y, X]

  