package psbp.specification.aggregatable.rec

import psbp.specification.types.&&

import psbp.specification.aggregatable.Aggregatable

import psbp.specification.types.LeftRec

private[psbp] trait RecAggregatable[A[+ _, + _], >-->[- _, + _]] extends Aggregatable[LeftRec[A], >-->] with RecStructureToRecReducer[A]:

  private[psbp] type RecAggregator[Z, Y, X] = Z >--> Y && Structure[Y, X]

  def recAggregate[Z, Y, X]: RecAggregator[Z, Y, X] => LeftRec[A][Z] >--> X =
    (`z>-->y`, structure) =>
      val reducer = structureToReducer(structure)
      val aggregator = (`z>-->y`, reducer)
      aggregate(aggregator)

